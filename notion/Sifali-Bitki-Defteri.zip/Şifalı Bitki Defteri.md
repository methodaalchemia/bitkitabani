# Şifalı Bitki Defteri

119 şifalı ve ritüel bitki: geleneksel kullanım, bilimsel kanıt düzeyi, güvenlik ve kaynaklar.

## Nasıl kullanılır
- **Bitkiler**: Evde olanları ve denediklerini işaretle; Kategori ve Güvenlik sütunlarına göre filtrele.
- **Toplama Takvimi**: Hangi ay neyin toplanabileceğini gör.
- **Kayıtlarım**: Topladığın, kuruttuğun ve demlediğin her şeyi not et.

> Bu defter bilgi amaçlıdır, tıbbi tavsiye değildir. Hamilelik, emzirme, çocuklar ve ilaç kullananlar için her bitkinin güvenlik notuna bak; bitkisel bir ürüne başlamadan önce hekimine ya da eczacına danış.

Kaynaklar ve güncellemeler: https://bitkitabani.com