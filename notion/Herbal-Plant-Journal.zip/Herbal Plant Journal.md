# Herbal Plant Journal

Medicinal and ritual plants with traditional uses, level of scientific evidence, safety notes and sources.

## How to use
- **Plants**: tick what is in your pantry and what you have tried; filter by safety.
- **My log**: note what you gather, dry and brew.

> For information only, not medical advice. Check the safety notes, especially in pregnancy, breastfeeding, for children and with medication.

Sources and updates: https://bitkitabani.com/en/